"""Python 3.9+ standard library only. Character n-gram TF-IDF, exact cosine search."""
from pathlib import Path
from collections import Counter
import argparse,json,math,re,sqlite3,hashlib
ROOT=Path(__file__).resolve().parent
DB=ROOT/'vector_store.sqlite3'
def terms(text):
    segments=re.findall(r'[\u4e00-\u9fff]+|[a-z0-9]+',text.lower())
    return Counter(s[i:i+n] for s in segments for n in (1,2,3) for i in range(len(s)-n+1))
def embed(text,idf):
    counts=terms(text)
    vec={t:(1+math.log(c))*idf[t] for t,c in counts.items() if t in idf}
    norm=math.sqrt(sum(v*v for v in vec.values()))
    return {t:v/norm for t,v in vec.items()} if norm else {}
def build():
    docs=[]
    for p in sorted(ROOT.glob('[0-9][0-9]_*.txt')):
        raw=p.read_text(encoding='utf-8')
        title=raw.splitlines()[0].split('：',1)[1]
        body=raw.split('【內容】\n',1)[1].split('\n\n【檢索練習問題】',1)[0]
        url=re.search(r'參考入口網址：(.*)',raw).group(1)
        docs.append((p.name,title,body,url,hashlib.sha256(p.read_bytes()).hexdigest()))
    if not docs: raise RuntimeError('No source documents')
    df=Counter(t for _,title,body,_,_ in docs for t in terms(title+' '+body))
    idf={t:math.log((1+len(docs))/(1+c))+1 for t,c in df.items()}
    with sqlite3.connect(DB) as con:
        con.executescript('DROP TABLE IF EXISTS documents; DROP TABLE IF EXISTS metadata; CREATE TABLE documents(id INTEGER PRIMARY KEY, filename TEXT, title TEXT, content TEXT, source_url TEXT, sha256 TEXT, vector_json TEXT); CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);')
        meta={'format_version':1,'method':'character_1_2_3gram_tfidf_l2','similarity':'cosine_exact','document_count':len(docs),'dimension':len(idf),'idf':idf,'chunking':'one short content section per document; title included; practice questions and boilerplate excluded','neural_embedding':False}
        con.executemany('INSERT INTO metadata VALUES (?,?)',[(k,json.dumps(v,ensure_ascii=False)) for k,v in meta.items()])
        for i,(name,title,body,url,digest) in enumerate(docs,1):
            con.execute('INSERT INTO documents VALUES (?,?,?,?,?,?,?)',(i,name,title,body,url,digest,json.dumps(embed(title+' '+body,idf),ensure_ascii=False)))
    print(json.dumps({k:v for k,v in meta.items() if k!='idf'},ensure_ascii=False))
def search(query,k=3):
    with sqlite3.connect(f'file:{DB}?mode=ro',uri=True) as con:
        idf=json.loads(con.execute("SELECT value FROM metadata WHERE key='idf'").fetchone()[0])
        q=embed(query,idf)
        if not q: return []
        result=[]
        for name,title,body,url,raw in con.execute('SELECT filename,title,content,source_url,vector_json FROM documents'):
            v=json.loads(raw); score=sum(x*v.get(t,0) for t,x in q.items())
            if score>0: result.append({'filename':name,'title':title,'score':round(score,6),'content':body,'source_url':url})
        return sorted(result,key=lambda x:(-x['score'],x['filename']))[:k]
if __name__=='__main__':
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('build'); s=sub.add_parser('search');s.add_argument('query');s.add_argument('--top-k',type=int,default=3)
    a=p.parse_args()
    if a.command=='build':build()
    else: print(json.dumps(search(a.query,max(1,a.top_k)),ensure_ascii=False,indent=2))
